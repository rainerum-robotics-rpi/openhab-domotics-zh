#ifndef DHT11_SENSOR_H
#define DHT11_SENSOR_H

extern void dht11_refresh(float* outTempDegC, float* outRelHumPrcnt);

#endif
